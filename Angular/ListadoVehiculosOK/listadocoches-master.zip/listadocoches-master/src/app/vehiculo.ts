export class Vehiculo {
  make_and_model!: string;
  color!: string;
  transmission!: string;
  doors!: number;
  fuel_type!:string;
  kilometrage!:number;
}
