import { Component } from '@angular/core';

@Component({
  selector: 'app-pmms',
  templateUrl: './pmms.component.html',
  styleUrls: ['./pmms.component.css']
})
export class PmmsComponent {

}
