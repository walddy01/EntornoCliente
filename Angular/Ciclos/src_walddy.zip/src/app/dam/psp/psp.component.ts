import { Component } from '@angular/core';

@Component({
  selector: 'app-psp',
  templateUrl: './psp.component.html',
  styleUrls: ['./psp.component.css']
})
export class PspComponent {

}
