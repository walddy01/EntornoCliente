import { Component } from '@angular/core';

@Component({
  selector: 'app-dwes',
  templateUrl: './dwes.component.html',
  styleUrls: ['./dwes.component.css']
})
export class DwesComponent {

}
