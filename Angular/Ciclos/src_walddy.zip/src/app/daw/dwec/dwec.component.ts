import { Component } from '@angular/core';

@Component({
  selector: 'app-dwec',
  templateUrl: './dwec.component.html',
  styleUrls: ['./dwec.component.css']
})
export class DwecComponent {

}
