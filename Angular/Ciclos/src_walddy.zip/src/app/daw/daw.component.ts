import { Component } from '@angular/core';

@Component({
  selector: 'app-daw',
  templateUrl: './daw.component.html',
  styleUrls: ['./daw.component.css']
})
export class DawComponent {

}
