import { Component } from '@angular/core';

@Component({
  selector: 'app-despliegue',
  templateUrl: './despliegue.component.html',
  styleUrls: ['./despliegue.component.css']
})
export class DespliegueComponent {

}
