import { Component } from '@angular/core';

@Component({
  selector: 'app-asir',
  templateUrl: './asir.component.html',
  styleUrls: ['./asir.component.css']
})
export class AsirComponent {

}
