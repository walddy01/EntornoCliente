import { Component } from '@angular/core';

@Component({
  selector: 'app-lm',
  templateUrl: './lm.component.html',
  styleUrls: ['./lm.component.css']
})
export class LmComponent {

}
