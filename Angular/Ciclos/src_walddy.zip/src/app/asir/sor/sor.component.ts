import { Component } from '@angular/core';

@Component({
  selector: 'app-sor',
  templateUrl: './sor.component.html',
  styleUrls: ['./sor.component.css']
})
export class SorComponent {

}
