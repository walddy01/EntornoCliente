import { Parador } from './parador';

describe('Parador', () => {
  it('should create an instance', () => {
    expect(new Parador()).toBeTruthy();
  });
});
