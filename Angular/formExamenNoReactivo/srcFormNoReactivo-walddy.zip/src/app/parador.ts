export class Parador {
  nombre!: string;
  ciudad!: string;
  habitaciones!: number;
}
