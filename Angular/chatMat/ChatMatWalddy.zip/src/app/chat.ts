export class Chat {
  id!: number;
  usuario!: string;
  fecha!: string;
  mensaje!: string;
}
