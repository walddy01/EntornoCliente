export class Empleado {
  id!: number;
  nombre!: string;
  direccion!: string;
  cargo!: string;
  edad!: number;
  imagen!: string;
}
