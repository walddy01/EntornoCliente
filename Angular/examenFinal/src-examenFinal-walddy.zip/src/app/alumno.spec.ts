import { Alumno } from './alumno';

describe('Alumno', () => {
  it('should create an instance', () => {
    expect(new Alumno()).toBeTruthy();
  });
});
