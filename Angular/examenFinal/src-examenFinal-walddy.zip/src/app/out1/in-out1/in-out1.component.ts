import { Component } from '@angular/core';

@Component({
  selector: 'app-in-out1',
  templateUrl: './in-out1.component.html',
  styleUrls: ['./in-out1.component.css']
})
export class InOut1Component {

}
