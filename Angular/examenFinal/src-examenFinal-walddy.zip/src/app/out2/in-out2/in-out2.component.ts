import { Component } from '@angular/core';

@Component({
  selector: 'app-in-out2',
  templateUrl: './in-out2.component.html',
  styleUrls: ['./in-out2.component.css']
})
export class InOut2Component {

}
